/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kerjaprojek;
import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
/**
 *
 * @author april
 */
public class KerjaProjek {
Connection koneksi; 
    public static Connection Koneksi() { 
        try { 
            Class.forName("com.mysql.jdbc.Driver");
     Connection koneksi = 
            DriverManager.getConnection("jdbc:mysql://localhost/db_restoran", "root", ""); 
     return koneksi; 
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);
   return null;
        }}

    Object getCon() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
    
